
import {post, requestBody} from '@loopback/rest';
import Stripe from 'stripe';
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', { apiVersion: '2022-11-15' });

export class PaymentController{
  constructor(private orderRepo: any){}
  @post('/payments/create-intent')
  async createIntent(@requestBody() body: any){
    const amount = body.amount || 100;
    const intent = await stripe.paymentIntents.create({ amount, currency: 'inr' });
    return {clientSecret: intent.client_secret};
  }
}
