
import {get, param, post, requestBody} from '@loopback/rest';
import {ProductRepository} from '../repositories/product.repository';

export class ProductController {
  constructor(private repo: ProductRepository){}
  @get('/products')
  async list(){ return this.repo.find(); }
  @get('/products/{id}')
  async get(@param.path.number('id') id: number){ return this.repo.findById(id); }
  @post('/products')
  async create(@requestBody() p:any){ return this.repo.create(p); }
}
