
import {juggler} from '@loopback/repository';
import {ProductRepository} from './repositories/product.repository';
import dotenv from 'dotenv';
dotenv.config();

async function seed(){
  const ds = new juggler.DataSource({name:'sqlite', connector:'memory'});
  const repo = new ProductRepository(ds);
  const products = [
    {name:'Bananas (1kg)', category:'Fruits', price:60, image:'https://via.placeholder.com/400x300?text=Bananas'},
    {name:'Milk 1L', category:'Dairy', price:45, image:'https://via.placeholder.com/400x300?text=Milk'},
    {name:'Bread', category:'Bakery', price:30, image:'https://via.placeholder.com/400x300?text=Bread'}
  ];
  for(const p of products) await repo.create(p as any);
  console.log('seeded products');
}

seed().catch(err=>console.error(err));
