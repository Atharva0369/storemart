
import {ApplicationConfig, RestApplication} from '@loopback/rest';
import {RepositoryMixin, juggler} from '@loopback/repository';
import path from 'path';
import dotenv from 'dotenv';
import {ProductController} from './controllers/product.controller';
import {OrderController} from './controllers/order.controller';
import {PaymentController} from './controllers/payment.controller';
import {ProductRepository} from './repositories/product.repository';
import {OrderRepository} from './repositories/order.repository';

dotenv.config();

async function main() {
  const app = new RestApplication({ rest: { port: +(process.env.PORT || 3000) } });
  app.static('/', path.join(__dirname, '../public'));

  const ds = new juggler.DataSource({name:'sqlite', connector:'memory'});
  app.bind('datasources.sqlite').to(ds);

  const productRepo = new ProductRepository(ds);
  const orderRepo = new OrderRepository(ds);

  app.controller(new ProductController(productRepo));
  app.controller(new OrderController(orderRepo));
  app.controller(new PaymentController(orderRepo));

  await app.start();
  console.log('StoreMart backend listening on', await app.restServer.url);
}

main().catch(err => { console.error(err); process.exit(1); });
