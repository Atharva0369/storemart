
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { ProductListComponent } from './features/products/product-list.component';
import { ProductCardComponent } from './features/products/product-card.component';
import { CartComponent } from './features/cart/cart.component';
import { CheckoutComponent } from './features/checkout/checkout.component';
import { WishlistComponent } from './features/wishlist/wishlist.component';
import { OrderHistoryComponent } from './features/orders/order-history.component';
import { HeaderComponent } from './shared/components/header.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    ProductCardComponent,
    CartComponent,
    CheckoutComponent,
    WishlistComponent,
    OrderHistoryComponent,
    HeaderComponent
  ],
  imports: [ BrowserModule, HttpClientModule, RouterModule.forRoot([
    {path: '', component: ProductListComponent},
    {path: 'cart', component: CartComponent},
    {path: 'checkout', component: CheckoutComponent},
    {path: 'wishlist', component: WishlistComponent},
    {path: 'orders', component: OrderHistoryComponent}
  ]) ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
