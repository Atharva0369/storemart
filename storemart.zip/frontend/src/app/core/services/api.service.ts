
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({providedIn: 'root'})
export class ApiService {
  private base = 'http://localhost:3000';
  constructor(private http: HttpClient) {}

  listProducts(): Observable<any> { return this.http.get(`${this.base}/products`); }
  getProduct(id: string) { return this.http.get(`${this.base}/products/${id}`); }
  getCategories() { return this.http.get(`${this.base}/categories`); }
  createOrder(payload: any) { return this.http.post(`${this.base}/orders`, payload); }
  listOrders(userId: string) { return this.http.get(`${this.base}/orders?userId=${userId}`); }
  createPaymentIntent(total: number) { return this.http.post(`${this.base}/payments/create-intent`, {amount: Math.round(total*100)}); }
}
