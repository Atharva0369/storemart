
import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../core/services/api.service';

@Component({
  selector: 'app-product-list',
  template: `
  <div class="p-6">
    <app-header></app-header>
    <h1 class="text-3xl font-bold mb-4">StoreMart — Fresh groceries & daily needs</h1>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      <app-product-card *ngFor="let p of products" [product]="p"></app-product-card>
    </div>
  </div>
  `
})
export class ProductListComponent implements OnInit{
  products: any[] = [];
  constructor(private api: ApiService) {}
  ngOnInit(){ this.api.listProducts().subscribe((r:any)=> this.products=r); }
}
