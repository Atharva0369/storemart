
module.exports = {
  content: ['./src/**/*.{html,ts}'],
  theme: { extend: { colors: { primary: '#0ea5a4', accent: '#f97316' }, fontSize: { 'xxs': '.65rem' } } },
  plugins: [],
}
